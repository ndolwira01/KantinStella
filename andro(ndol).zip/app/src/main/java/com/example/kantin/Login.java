package com.example.kantin;

import android.os.Bundle;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    Button Login, Create;
    EditText nama,password;
    String user, pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        nama=findViewById(R.id.editTextText);
        password=findViewById(R.id.editTextNumberPassword);
        Login=findViewById(R.id.next);
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                user=nama.getText().toString();
                pass=password.getText().toString();

                if(user.equals("Nando"))  pass.equals("nando123");{
                    Toast.makeText(Login.this, "Berhasil Login", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Login.this, Menu.class));
                }
            }
        });

        Create=findViewById(R.id.button2);
        Create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Login.this, com.example.kantin.Create.class));
            }
        });
    }
}